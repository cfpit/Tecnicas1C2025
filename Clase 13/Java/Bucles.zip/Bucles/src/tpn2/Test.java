package tpn2;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        /*
            Crear un programa que permita ingresar la clave 
            del home banking. Si se fallan 3 veces, se 
            bloquea el acceso. La clave es "1234". Informar 
            si se logró ingresar la clave correctamente o si 
            se bloqueó el acceso. Avisar al usuario cuántas 
            veces falló y cuantas oportunidades le quedan.
        */
        
        //creo un objeto de tipo Scanner que va a leer dsd el teclado
        //System.in es el teclado (consola estandar de entrada de datos)
        //Scanner(System.in) es el metodo constructor (permite crear objetos de esta clase)
        //new Scanner(System.in) es un objeto que pertenece a la clase Scanner
        //La clase Scanner esta definida en el diccionario del lenguaje(API -> JSE)
        //JSE es el API que permite construir aplicaciones de escritorio
        //Scanner lector = new Scanner(System.in); significa que guardo en 
        //la variable lector, el objeto de clase Scanner.
        Scanner lector = new Scanner(System.in);
        int fallidos = 0; //contador de ingresos erroneos
        
        do {
            System.out.println("Ingrese su clave: ");
            String clave = lector.next();
            
            //si la clave ingresada es correcta, salgo del bucle
            if (clave.equals("1234")) {
                break;
            }
            
            fallidos ++;
            System.out.println("Chances Restantes: " + (3 - fallidos));
            
        } while (fallidos < 3);
        
        if (fallidos == 3) {
            System.out.println("Acceso Bloqueado");
        } else {
            System.out.println("Bienvenida/o!!");
        }
    }
}
