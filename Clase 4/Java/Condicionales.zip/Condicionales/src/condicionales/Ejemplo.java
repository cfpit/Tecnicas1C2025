

package condicionales;

import java.util.Scanner;


public class Ejemplo {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        System.out.println("Decime como te llamas: ");
        
        String nombre = lector.next();
        
        System.out.println("nombre = " + nombre);
    }
}
