package cicloDoWhile;

public class Test {
    public static void main(String[] args) {
        System.out.println("inicio");
        int cont = 15;
        do 
        {
            System.out.println("cont = " + cont);
            cont --;
        } while (cont > 0);
        System.out.println("fin");
    }
}
