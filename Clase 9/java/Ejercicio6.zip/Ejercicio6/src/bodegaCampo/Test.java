package bodegaCampo;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        //creo un objeto de tipo Scanner que lee dsd el teclado
        //la cantidad de comensales y la almaceno en una variable
        Scanner lector = new Scanner(System.in);
        
        
        //ingreso y almacenamiento en variable de la cantidad de personas
        System.out.println("Ingrese la cantidad de comensales");
        int p = lector.nextInt();
        
        //logica de decision
        if (p <= 200) 
        {
            System.out.println("precio = " + (p * 95) + " $");
        } 
        else 
        {
            if (p > 200 && p <= 300) 
            {
                System.out.println("precio = " + (p * 85) + " $");
            } 
            else 
            {
                System.out.println("precio = " + (p * 75) + " $");
            }
        }
        
        
    }
}
