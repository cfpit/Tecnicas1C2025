package cicloFor;

public class Test {
    public static void main(String[] args) {
        int cont;
        
        for (cont = 10; cont <= 25; cont+=2) {
            System.out.println("contador = " + cont);
        }
        
        System.out.println(cont);
    }
}

