document.addEventListener('DOMContentLoaded', function() {
    const calculateButton = document.getElementById('calculate-btn');
    const resultDiv = document.getElementById('result');

    calculateButton.addEventListener('click', function() {
        const weight = parseFloat(document.getElementById('weight').value);
        const height = parseFloat(document.getElementById('height').value);

        if (isNaN(weight) || isNaN(height) || weight <= 0 || height <= 0) {
            resultDiv.innerHTML = '<div class="alert alert-danger">Por favor, ingrese un peso y una altura válidos.</div>';
            return;
        }

        const bmi = weight / (height * height);
        let category = '';

        if (bmi < 18.5) category = 'Bajo peso';
        else if (bmi < 25) category = 'Peso normal';
        else if (bmi < 30) category = 'Sobrepeso';
        else category = 'Obesidad';

        resultDiv.innerHTML = `<div class="alert alert-info">Su IMC es <strong>${bmi.toFixed(2)}</strong> (${category})</div>`;
    });
});