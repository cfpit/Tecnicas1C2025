package cicloWhile;

public class Test {
    public static void main(String[] args) {
        System.out.println("Inicio");
        
        int cont = 1;
        
        while (cont <= 10) {
            System.out.println("cont = " + cont);
            cont ++;
        }
        
        System.out.println("Fin");
    }
}
